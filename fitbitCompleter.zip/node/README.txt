===== TypeScript Sample: Node.js =====

=== Overview ===

This sample implements a very basic node.js application using TypeScript

=== Running ===
For HttpServer
tsc --module node HttpServer.ts
node HttpServer.js

For TcpServer
tsc --module node TcpServer.ts
node TcpServer.js