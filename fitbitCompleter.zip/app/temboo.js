var tsession = require("temboo/core/temboosession");
exports.session = new tsession.TembooSession("omer", "FitbitCompleter", "61191725-521b-4900-a");
