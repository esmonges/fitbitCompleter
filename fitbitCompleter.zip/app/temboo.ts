
var tsession = require("temboo/core/temboosession");
export var session = new tsession.TembooSession(
  "omer", // Account name
  "FitbitCompleter", // App key name
  "61191725-521b-4900-a" // App key value
);

